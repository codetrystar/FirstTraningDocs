/*
partTree: 模块
*/


var stuff = require('./count');

console.log(stuff.counter(['ruby', 'nodejs', 'react']));
console.log(stuff.adder(3,2));
console.log(stuff.pi);