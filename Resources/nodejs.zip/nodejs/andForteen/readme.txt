打开浏览器，输入
http://localhost:3000/api_records?name=js&age=8