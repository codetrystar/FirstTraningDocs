/*
partTwo: 函数
*/


//1.

function sayHi(){
    console.log('Hi');
}

sayHi();


//2.

// var sayBye = function(){
//     console.log('Bye');
// }
// sayBye();

// //3.依次调用
// function callFunction(fun) {
//     fun();
// }

// var sayBye = function () {
//     console.log('Bye');
// }

// callFunction(sayBye);

//4.
// function callFunction(fun,name) {
//     fun(name);
// }

// var sayBye = function (name) {
//     console.log(name+' Bye');
// }

// callFunction(sayBye,'xiaohua');

//5.

// function callFunction(fun, name) {
//     fun(name);
// }

// callFunction(function (name) {
//     console.log(name + ' Bye');
// },'xiaohua')