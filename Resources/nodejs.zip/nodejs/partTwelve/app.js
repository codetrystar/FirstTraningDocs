
var server = require('./server');

server.startServer();